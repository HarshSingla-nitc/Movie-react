function MovieCard({ movie }) {
    return (
        <li className="movie-card">
            <img
                src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
                alt={movie.title}
            />
            <h4>⭐ {movie.vote_average.toFixed(1)}</h4>
            <div className="details">
                <h3>{movie.title}</h3>
                <h5>
                    {movie.release_date
                        ? movie.release_date.slice(0, 4)
                        : "N/A"}
                </h5>

            </div>

        </li>
    )
}

export default MovieCard