import { useState, useEffect } from 'react';
import './App.css';
import MovieCard from './components/MovieCard';

function App() {
  const API_KEY = "b6568eea4b4cc35e3282517689234d03";
  const allMoviesURL = `https://api.themoviedb.org/3/discover/movie?api_key=${API_KEY}`;
  const popularURL = `https://api.themoviedb.org/3/movie/popular?api_key=${API_KEY}`;
const trendingURL = `https://api.themoviedb.org/3/trending/movie/day?api_key=${API_KEY}`;  const highestURL = `https://api.themoviedb.org/3/movie/top_rated?api_key=${API_KEY}`;
  const upcomingURL = `https://api.themoviedb.org/3/movie/upcoming?api_key=${API_KEY}`;

  const [movies, setMovies] = useState([]);
  const [search, setSearch] = useState("");
  const [searchedTerm, setSearchedTerm] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [activeGenre, setActiveGenre] = useState("all");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [popular, setPopular] = useState([]);
  const [trending, setTrending] = useState([]);
  const [topRated, setTopRated] = useState([]);
  const [upcoming, setUpcoming] = useState([]);
  const [searched, setSearched] = useState([]);

  async function getMovies() {
    setLoading(true);
    try {
      const response = await fetch(allMoviesURL);
      const data = await response.json();
      setMovies(data.results);
    }
    catch (error) {
      setError("Failed to fetch movies");
    }
    setLoading(false);
  }

  async function getPopularMovies() {
    setLoading(true);
    try {
      const response = await fetch(popularURL);
      const data = await response.json();
      setPopular(data.results);
    }
    catch (error) {
      setError("Failed to fetch popular movies");
    }
    setLoading(false);
  }

  async function getTrendingMovies() {
    setLoading(true);
    try {
      const response = await fetch(trendingURL);
      const data = await response.json();
      setTrending(data.results);
    }
    catch (error) {
      setError("Failed to fetch trending movies");
    }
    setLoading(false);
  }

  async function getTopRatedMovies() {
    setLoading(true);
    try {
      const response = await fetch(highestURL);
      const data = await response.json();
      setTopRated(data.results);
    }
    catch (error) {
      setError("Failed to fetch top rated movies");
    }
    setLoading(false);
  }

  async function getUpcomingMovies() {
    setLoading(true);
    try {
      const response = await fetch(upcomingURL);
      const data = await response.json();
      setUpcoming(data.results);
    }
    catch (error) {
      setError("Failed to fetch upcoming movies");
    }
    setLoading(false);
  }

  async function getSearchedMovies() {
    const searchURL =
      `https://api.themoviedb.org/3/search/movie?api_key=${API_KEY}&query=${encodeURIComponent(search.toLowerCase())}`;
    setLoading(true);
    try {
      const response = await fetch(searchURL);
      const data = await response.json();
      setSearched(data.results);
      setSearchedTerm(search);
      setActiveGenre("");
      setIsSearching(true);
    }
    catch (error) {
      setError("Failed to fetch movies");
    }
    setLoading(false);
  }

  async function filterMovies(genreId) {
    setActiveGenre(genreId);
    setIsSearching(false);
    setSearch("");

    if (genreId === "all") {
      getMovies();
      return;
    }

    setLoading(true);
    try {
      const genreURL =
        `https://api.themoviedb.org/3/discover/movie?api_key=${API_KEY}&with_genres=${genreId}`;
      const response = await fetch(genreURL);
      const data = await response.json();
      setMovies(data.results);
    }
    catch (error) {
      setError("Failed to fetch movies");
    }
    setLoading(false);
  }

  useEffect(() => {
    getMovies();
    getPopularMovies();
    getTopRatedMovies();
    getTrendingMovies();
    getUpcomingMovies();
  }, []);

  return (
    <div className="container">
      <div className="sectionA">
        <nav>
          <img
            src="movie-clapperboard-part-2-svgrepo-com.svg"
            height="25px"
            alt="movie-logo"
          />
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            type="text"
            placeholder="Search your movie"
          />
          <button onClick={getSearchedMovies}>
            <img
              src="search-svgrepo-com.svg"
              alt="search"
            />
          </button>
        </nav>
        <div className="movie-filters">
          <button
            className={`filter-btn ${activeGenre === "all" ? "active" : ""}`}
            onClick={() => filterMovies("all")}
          >
            All
          </button>
          <button
            className={`filter-btn ${activeGenre === 28 ? "active" : ""}`}
            onClick={() => filterMovies(28)}
          >
            Action
          </button>
          <button
            className={`filter-btn ${activeGenre === 12 ? "active" : ""}`}
            onClick={() => filterMovies(12)}
          >
            Adventure
          </button>
          <button
            className={`filter-btn ${activeGenre === 16 ? "active" : ""}`}
            onClick={() => filterMovies(16)}
          >
            Animation
          </button>
          <button
            className={`filter-btn ${activeGenre === 35 ? "active" : ""}`}
            onClick={() => filterMovies(35)}
          >
            Comedy
          </button>
          <button
            className={`filter-btn ${activeGenre === 80 ? "active" : ""}`}
            onClick={() => filterMovies(80)}
          >
            Crime
          </button>
          <button
            className={`filter-btn ${activeGenre === 18 ? "active" : ""}`}
            onClick={() => filterMovies(18)}
          >
            Drama
          </button>
          <button
            className={`filter-btn ${activeGenre === 27 ? "active" : ""}`}
            onClick={() => filterMovies(27)}
          >
            Horror
          </button>
          <button
            className={`filter-btn ${activeGenre === 10749 ? "active" : ""}`}
            onClick={() => filterMovies(10749)}
          >
            Romance
          </button>
          <button
            className={`filter-btn ${activeGenre === 878 ? "active" : ""}`}
            onClick={() => filterMovies(878)}
          >
            Science Fiction
          </button>
          <button
            className={`filter-btn ${activeGenre === 53 ? "active" : ""}`}
            onClick={() => filterMovies(53)}
          >
            Thriller
          </button>
          <button
            className={`filter-btn ${activeGenre === 14 ? "active" : ""}`}
            onClick={() => filterMovies(14)}
          >
            Fantasy
          </button>
        </div>
      </div>
      <div className="searcheddiv trending">
        <h2 className="searchedh2">
          {isSearching ? `Results for "${searchedTerm}"` : "All Movies"}
        </h2>
        <ul className="searchedul">
          {(isSearching ? searched : movies).map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </ul>
      </div>
      <div className="popular trending">
        <h2>Popular</h2>
        <ul className="popularul">
          {popular.map((movie) => (
            <MovieCard key={movie.id} movie={movie}></MovieCard>
          ))}
        </ul>
      </div>
      <div className="trended trending">
        <h2>Trending</h2>
        <ul className="trendingul">
          {trending.map((movie) => (
            <MovieCard key={movie.id} movie={movie}></MovieCard>
          ))}
        </ul>
      </div>
      <div className="highest trending">
        <h2>Highest Rated</h2>
        <ul className="highestul">
          {topRated.map((movie) => (
            <MovieCard key={movie.id} movie={movie}></MovieCard>
          ))}
        </ul>
      </div>
      <div className="upcoming trending">
        <h2>Upcoming</h2>
        <ul className="upcomingul">
          {upcoming.map((movie) => (
            <MovieCard key={movie.id} movie={movie}></MovieCard>
          ))}
        </ul>
      </div>
    </div>
  )
}

export default App
